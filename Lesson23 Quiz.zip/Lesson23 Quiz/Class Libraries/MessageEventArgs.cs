﻿using System;

namespace Class_Libraries
{
    public class MessageEventArgs:EventArgs
    {
        public string Message { get; set; }
    }
}
